#!/bin/bash
python -m web_agent_site.app --log
