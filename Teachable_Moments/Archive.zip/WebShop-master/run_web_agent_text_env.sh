#!/bin/bash
python -m run_envs.run_web_agent_text_env
