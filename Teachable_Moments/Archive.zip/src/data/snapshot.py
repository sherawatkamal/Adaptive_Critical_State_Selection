"""
Snapshot and labeling data structures for teachability characterization.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Literal, Dict
from enum import Enum
import base64
import json
import pickle
from pathlib import Path


class ErrorType(Enum):
    """Classification of error types for teacher hints."""
    AFFORDANCE_MISS = "affordance_miss"
    ATTRIBUTE_CONFUSION = "attribute_confusion"
    PLANNING_ERROR = "planning_error"
    EXPLORATION_FAILURE = "exploration_failure"
    UNKNOWN = "unknown"


@dataclass
class TeacherHint:
    """Teacher-generated hint for a failure snapshot."""
    
    suggested_action: str
    rationale: str
    error_type: ErrorType
    confidence: Literal["high", "medium", "low"]
    model: str = "gpt-4o"
    timestamp: Optional[float] = None
    
    def to_dict(self) -> dict:
        return {
            "suggested_action": self.suggested_action,
            "rationale": self.rationale,
            "error_type": self.error_type.value,
            "confidence": self.confidence,
            "model": self.model,
            "timestamp": self.timestamp,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "TeacherHint":
        return cls(
            suggested_action=data["suggested_action"],
            rationale=data["rationale"],
            error_type=ErrorType(data.get("error_type", "unknown")),
            confidence=data.get("confidence", "medium"),
            model=data.get("model", "gpt-4o"),
            timestamp=data.get("timestamp"),
        )


@dataclass
class Snapshot:
    """
    A snapshot of agent state at a specific point in a trajectory.
    Used as the unit of analysis for teachability labeling.
    """
    
    # Identifiers
    id: str                                    # "{task_id}_step{step_idx}"
    task_id: str
    step_idx: int
    trajectory_id: str
    
    # Environment state
    env_state_bytes: Optional[bytes] = None    # Serialized for restore
    observation: str = ""
    valid_actions: list[str] = field(default_factory=list)
    
    # Agent context
    agent_prefix: str = ""                     # Prompt + history
    last_action: Optional[str] = None
    action_type: Optional[str] = None          # click/search/back/etc.
    
    # Teacher hint (cached)
    teacher_hint: Optional[TeacherHint] = None
    
    # Metadata
    trajectory_outcome: str = "failure"        # failure | success
    timestamp: Optional[float] = None
    
    def with_prefix(self, new_prefix: str) -> "Snapshot":
        """Create a copy with modified prefix (for CPT patching)."""
        return Snapshot(
            id=self.id,
            task_id=self.task_id,
            step_idx=self.step_idx,
            trajectory_id=self.trajectory_id,
            env_state_bytes=self.env_state_bytes,
            observation=self.observation,
            valid_actions=self.valid_actions.copy(),
            agent_prefix=new_prefix,
            last_action=self.last_action,
            action_type=self.action_type,
            teacher_hint=self.teacher_hint,
            trajectory_outcome=self.trajectory_outcome,
            timestamp=self.timestamp,
        )
    
    def to_dict(self) -> dict:
        """Convert to JSON-serializable dictionary.
        
        We include env_state_bytes as base64 so snapshots can be restored later
        (required for leverage, CPT, micro-training validation).
        """
        env_state_b64 = None
        if self.env_state_bytes is not None:
            env_state_b64 = base64.b64encode(self.env_state_bytes).decode("ascii")
        
        return {
            "id": self.id,
            "task_id": self.task_id,
            "step_idx": self.step_idx,
            "trajectory_id": self.trajectory_id,
            "env_state_b64": env_state_b64,
            "observation": self.observation,
            "valid_actions": self.valid_actions,
            "agent_prefix": self.agent_prefix,
            "last_action": self.last_action,
            "action_type": self.action_type,
            "teacher_hint": self.teacher_hint.to_dict() if self.teacher_hint else None,
            "trajectory_outcome": self.trajectory_outcome,
            "timestamp": self.timestamp,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Snapshot":
        """Parse a snapshot from a (possibly legacy) dictionary schema.

        The repo has accumulated a few historical snapshot schemas. This loader is intentionally
        forgiving so that downstream labeling/training code can assume a canonical `Snapshot`.
        """

        # Support `LabeledSnapshot.to_dict()` payloads that include a nested `snapshot` field.
        if "snapshot" in data and isinstance(data.get("snapshot"), dict) and "id" not in data:
            return cls.from_dict(data["snapshot"])  # type: ignore[arg-type]

        # Teacher hint may be stored either as a dict or already-parsed object.
        teacher_hint = None
        raw_th = data.get("teacher_hint")
        if raw_th:
            try:
                teacher_hint = raw_th if isinstance(raw_th, TeacherHint) else TeacherHint.from_dict(raw_th)
            except Exception:
                teacher_hint = None

        # Decode env_state_bytes from base64 if present (best-effort).
        env_state_bytes = None
        env_b64 = data.get("env_state_b64") or data.get("env_state")
        if env_b64:
            try:
                env_state_bytes = base64.b64decode(env_b64)
            except Exception:
                env_state_bytes = None

        # Canonical identifiers (fall back to common legacy keys).
        trajectory_id = data.get("trajectory_id") or data.get("traj_id") or data.get("trajectory") or "unknown"
        step_idx = int(data.get("step_idx", data.get("step_index", data.get("step", 0))))
        task_id = data.get("task_id") or data.get("session_id") or data.get("task") or "unknown"
        snap_id = data.get("id") or data.get("snapshot_id") or f"{trajectory_id}_{step_idx}"

        # Observation/action space (support older field names).
        observation = data.get("observation")
        if observation is None:
            observation = data.get("state", "")

        valid_actions = data.get("valid_actions")
        if valid_actions is None:
            valid_actions = data.get("available_actions", [])
        if valid_actions is None:
            valid_actions = []

        # Ensure agent_prefix is a string (some scripts wrote None).
        agent_prefix = data.get("agent_prefix")
        if agent_prefix is None:
            agent_prefix = ""

        # Last action (accept multiple historical names).
        last_action = (
            data.get("last_action")
            or data.get("action_taken")
            or data.get("action")
            or data.get("student_action")
        )

        return cls(
            id=str(snap_id),
            task_id=str(task_id),
            step_idx=step_idx,
            trajectory_id=str(trajectory_id),
            env_state_bytes=env_state_bytes,
            observation=str(observation or ""),
            valid_actions=list(valid_actions or []),
            agent_prefix=str(agent_prefix),
            last_action=str(last_action) if last_action is not None else None,
            action_type=data.get("action_type"),
            teacher_hint=teacher_hint,
            trajectory_outcome=data.get("trajectory_outcome", "failure"),
            timestamp=data.get("timestamp"),
        )


@dataclass
class LeverageLabels:
    """
    Two-estimator leverage with aligned naming:
    - Estimator A (L_local): single-step expert leverage
    - Estimator B (L_upper): expert upper bound (full control)
    """
    
    # Baseline
    p_policy: float                            # P(success | student continues)
    
    # Estimator A: Single-step expert (current action focus)
    p_force: float                             # P(success | force expert action, then student)
    L_local: float                             # p_force - p_policy (ACTIONABILITY)
    
    # Estimator B: Expert upper bound (full control)
    p_expert: float                            # P(success | expert takes over completely)
    L_upper: float                             # p_expert - p_policy (UPPER BOUND)
    
    # Optional with defaults
    n_force_rollouts: int = 7
    n_expert_rollouts: int = 2
    leverage_gap: float = 0.0                  # L_upper - L_local (room beyond single action)
    
    def __post_init__(self):
        self.leverage_gap = self.L_upper - self.L_local
    
    def to_dict(self) -> dict:
        return {
            "p_policy": self.p_policy,
            "p_force": self.p_force,
            "L_local": self.L_local,
            "n_force_rollouts": self.n_force_rollouts,
            "p_expert": self.p_expert,
            "L_upper": self.L_upper,
            "n_expert_rollouts": self.n_expert_rollouts,
            "leverage_gap": self.leverage_gap,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "LeverageLabels":
        return cls(
            p_policy=data["p_policy"],
            p_force=data["p_force"],
            L_local=data["L_local"],
            p_expert=data["p_expert"],
            L_upper=data["L_upper"],
            n_force_rollouts=data.get("n_force_rollouts", 7),
            n_expert_rollouts=data.get("n_expert_rollouts", 2),
        )


@dataclass
class DepthLabels:
    """Recovery depth measurements."""
    
    d_expert: int                              # Steps back until expert can recover
    d_force: int                               # Steps back until single-action fix works
    depth_gap: int = field(default=0)          # d_force - d_expert
    
    def __post_init__(self):
        self.depth_gap = self.d_force - self.d_expert
    
    def to_dict(self) -> dict:
        return {
            "d_expert": self.d_expert,
            "d_force": self.d_force,
            "depth_gap": self.depth_gap,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "DepthLabels":
        return cls(
            d_expert=data["d_expert"],
            d_force=data["d_force"],
        )


@dataclass
class CPTLabels:
    """CPT with single-stage allocation (n=2 per condition)."""
    
    # Base and placebo
    p_base: float
    p_placebo: float
    n_per_condition: int = 2                   # Fixed at 2 for v8
    
    # Patch results
    patch_gain_raw: dict[str, float] = field(default_factory=dict)  # {demo, contrast, hint} -> Δ_raw
    patch_gain_net: dict[str, float] = field(default_factory=dict)  # {demo, contrast, hint} -> Δ_net
    
    # Derived
    ELP_raw: float = 0.0                       # max Δ_raw
    ELP_net: float = 0.0                       # max Δ_net (PRIMARY)
    route_raw: str = ""                        # argmax Δ_raw
    route_net: str = ""                        # argmax Δ_net
    
    # Retention evaluation (optional)
    p_base_retention: Optional[float] = None   # P(success) on new tasks after training
    p_placebo_retention: Optional[float] = None
    patch_retention: dict[str, float] = field(default_factory=dict)  # {demo, contrast, hint} -> retention
    
    # Metadata
    total_episodes: int = 10                   # Should be 10 (5 conditions × 2)
    
    def __post_init__(self):
        if self.patch_gain_raw:
            self.ELP_raw = max(self.patch_gain_raw.values())
            self.route_raw = max(self.patch_gain_raw, key=self.patch_gain_raw.get)
        if self.patch_gain_net:
            self.ELP_net = max(self.patch_gain_net.values())
            self.route_net = max(self.patch_gain_net, key=self.patch_gain_net.get)
    
    def to_dict(self) -> dict:
        return {
            "p_base": self.p_base,
            "p_placebo": self.p_placebo,
            "n_per_condition": self.n_per_condition,
            "patch_gain_raw": self.patch_gain_raw,
            "patch_gain_net": self.patch_gain_net,
            "ELP_raw": self.ELP_raw,
            "ELP_net": self.ELP_net,
            "route_raw": self.route_raw,
            "route_net": self.route_net,
            "p_base_retention": self.p_base_retention,
            "p_placebo_retention": self.p_placebo_retention,
            "patch_retention": self.patch_retention,
            "total_episodes": self.total_episodes,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "CPTLabels":
        return cls(
            p_base=data["p_base"],
            p_placebo=data["p_placebo"],
            n_per_condition=data.get("n_per_condition", 2),
            patch_gain_raw=data.get("patch_gain_raw", {}),
            patch_gain_net=data.get("patch_gain_net", {}),
            p_base_retention=data.get("p_base_retention"),
            p_placebo_retention=data.get("p_placebo_retention"),
            patch_retention=data.get("patch_retention", {}),
            total_episodes=data.get("total_episodes", 10),
        )


# Quadrant type alias
QuadrantLabel = Literal["Q1_highU_highL", "Q2_highU_lowL", "Q3_lowU_lowL", "Q4_lowU_highL"]


@dataclass
class LabeledSnapshot:
    """
    Fully labeled snapshot with all teachability metrics.
    This is the primary data structure for experiments.
    """
    
    snapshot: Snapshot
    
    # Uncertainty
    U: float                                   # Primary uncertainty measure (entropy)
    uncertainty_features: dict[str, float] = field(default_factory=dict)
    
    # Leverage (v8: aligned naming)
    leverage: Optional[LeverageLabels] = None
    
    # CPT
    cpt: Optional[CPTLabels] = None
    
    # Depth
    depth: Optional[DepthLabels] = None
    
    # Quadrant (v8: primary organizing principle)
    quadrant: QuadrantLabel = "Q1_highU_highL"
    
    # Training/evaluation splits
    held_out: bool = False
    split: str = "train"                       # train | val | test
    
    def to_dict(self) -> dict:
        return {
            "snapshot": self.snapshot.to_dict(),
            "U": self.U,
            "uncertainty_features": self.uncertainty_features,
            "leverage": self.leverage.to_dict() if self.leverage else None,
            "cpt": self.cpt.to_dict() if self.cpt else None,
            "depth": self.depth.to_dict() if self.depth else None,
            "quadrant": self.quadrant,
            "held_out": self.held_out,
            "split": self.split,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "LabeledSnapshot":
        snapshot = Snapshot.from_dict(data["snapshot"])
        leverage = LeverageLabels.from_dict(data["leverage"]) if data.get("leverage") else None
        cpt = CPTLabels.from_dict(data["cpt"]) if data.get("cpt") else None
        depth = DepthLabels.from_dict(data["depth"]) if data.get("depth") else None
        
        return cls(
            snapshot=snapshot,
            U=data["U"],
            uncertainty_features=data.get("uncertainty_features", {}),
            leverage=leverage,
            cpt=cpt,
            depth=depth,
            quadrant=data.get("quadrant", "Q1_highU_highL"),
            held_out=data.get("held_out", False),
            split=data.get("split", "train"),
        )
    
    def save(self, path: Union[Path, str]) -> None:
        """Save labeled snapshot to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
    
    @classmethod
    def load(cls, path: Union[Path, str]) -> "LabeledSnapshot":
        """Load labeled snapshot from file."""
        with open(path) as f:
            return cls.from_dict(json.load(f))
