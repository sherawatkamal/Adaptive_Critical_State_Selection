"""
Trajectory data structures for storing agent execution traces.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import Optional, Any, Union
import json
import pickle
from pathlib import Path



@dataclass
class TrajectoryStep:
    """A single step in an agent trajectory."""
    
    step_idx: int
    observation: str
    action: str
    action_type: Optional[str] = None  # click/search/back/etc.
    reward: float = 0.0
    done: bool = False
    info: dict = field(default_factory=dict)
    
    # State serialization for restore
    env_state_bytes: Optional[bytes] = None
    valid_actions: list[str] = field(default_factory=list)
    
    # Agent context
    agent_prefix: str = ""
    action_probs: Optional[dict[str, float]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization.
        
        Includes env_state_bytes as base64 for JSON compatibility.
        """
        env_state_b64 = None
        if self.env_state_bytes is not None:
            env_state_b64 = base64.b64encode(self.env_state_bytes).decode("ascii")
        
        return {
            "step_idx": self.step_idx,
            "observation": self.observation,
            "action": self.action,
            "action_type": self.action_type,
            "reward": self.reward,
            "done": self.done,
            "info": self.info,
            "env_state_b64": env_state_b64,
            "valid_actions": self.valid_actions,
            "agent_prefix": self.agent_prefix,
            "action_probs": self.action_probs,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "TrajectoryStep":
        """Create from dictionary."""
        # Decode env_state_bytes from base64 if present
        env_state_bytes = None
        if data.get("env_state_b64"):
            try:
                env_state_bytes = base64.b64decode(data["env_state_b64"])
            except Exception:
                env_state_bytes = None
        
        # Filter out base64 field and add decoded bytes
        filtered = {k: v for k, v in data.items() if k not in ("env_state_bytes", "env_state_b64")}
        return cls(env_state_bytes=env_state_bytes, **filtered)


@dataclass
class Trajectory:
    """A complete agent trajectory from start to termination."""
    
    trajectory_id: str
    task_id: str
    steps: list[TrajectoryStep] = field(default_factory=list)
    
    # Outcome
    success: bool = False
    final_reward: float = 0.0
    
    # Metadata
    agent_model: str = ""
    timestamp: Optional[float] = None
    config: dict = field(default_factory=dict)
    
    @property
    def length(self) -> int:
        """Number of steps in trajectory."""
        return len(self.steps)
    
    @property
    def outcome(self) -> str:
        """String representation of outcome."""
        return "success" if self.success else "failure"
    
    def get_step(self, idx: int) -> Optional[TrajectoryStep]:
        """Get step by index, or None if out of range."""
        if 0 <= idx < len(self.steps):
            return self.steps[idx]
        return None
    
    def get_actions(self) -> list[str]:
        """Get list of all actions taken."""
        return [step.action for step in self.steps]
    
    def get_observations(self) -> list[str]:
        """Get list of all observations."""
        return [step.observation for step in self.steps]
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "trajectory_id": self.trajectory_id,
            "task_id": self.task_id,
            "steps": [step.to_dict() for step in self.steps],
            "success": self.success,
            "final_reward": self.final_reward,
            "agent_model": self.agent_model,
            "timestamp": self.timestamp,
            "config": self.config,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Trajectory":
        """Create from dictionary."""
        steps = [TrajectoryStep.from_dict(s) for s in data.get("steps", [])]
        return cls(
            trajectory_id=data["trajectory_id"],
            task_id=data["task_id"],
            steps=steps,
            success=data.get("success", False),
            final_reward=data.get("final_reward", 0.0),
            agent_model=data.get("agent_model", ""),
            timestamp=data.get("timestamp"),
            config=data.get("config", {}),
        )
    
    def save(self, path: Path | str) -> None:
        """Save trajectory to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if path.suffix == ".json":
            with open(path, "w") as f:
                json.dump(self.to_dict(), f, indent=2)
        elif path.suffix == ".pkl":
            with open(path, "wb") as f:
                pickle.dump(self, f)
        else:
            raise ValueError(f"Unknown file format: {path.suffix}")
    
    @classmethod
    def load(cls, path: Path | str) -> "Trajectory":
        """Load trajectory from file."""
        path = Path(path)
        
        if path.suffix == ".json":
            with open(path) as f:
                return cls.from_dict(json.load(f))
        elif path.suffix == ".pkl":
            with open(path, "rb") as f:
                return pickle.load(f)
        else:
            raise ValueError(f"Unknown file format: {path.suffix}")


def partition_trajectories(
    trajectories: list[Trajectory],
) -> tuple[list[Trajectory], list[Trajectory]]:
    """Partition trajectories into successes and failures."""
    successes = [t for t in trajectories if t.success]
    failures = [t for t in trajectories if not t.success]
    return successes, failures
