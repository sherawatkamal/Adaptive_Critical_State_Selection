"""
Core data structures for the teachable moments framework.
"""

from .trajectory import Trajectory, TrajectoryStep
from .snapshot import (
    Snapshot,
    TeacherHint,
    ErrorType,
    LeverageLabels,
    DepthLabels,
    CPTLabels,
    LabeledSnapshot,
)
from .webshop_env import WebShopEnvWrapper

__all__ = [
    "Trajectory",
    "TrajectoryStep", 
    "Snapshot",
    "TeacherHint",
    "ErrorType",
    "LeverageLabels",
    "DepthLabels",
    "CPTLabels",
    "LabeledSnapshot",
    "WebShopEnvWrapper",
]
