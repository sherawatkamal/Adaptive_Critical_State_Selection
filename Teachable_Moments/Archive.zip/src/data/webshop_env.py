"""
WebShop environment wrapper for trajectory collection and state restoration.
"""

import os
import pickle
from dataclasses import dataclass
from typing import Optional, Any, Callable, Union
from pathlib import Path
import sys


def _maybe_add_webshop_to_syspath() -> None:
    """Add a vendored or sibling WebShop checkout to sys.path if present."""
    candidates: list[Path] = []

    # Check environment variable first
    env_path = os.getenv("WEBSHOP_PATH")
    if env_path:
        candidates.append(Path(env_path))

    # Check relative to this file's location
    repo_root = Path(__file__).resolve().parents[2]
    candidates.extend([
        repo_root / "WebShop-master",
        repo_root / "WebShop",
        repo_root.parent / "WebShop-master",
        repo_root.parent / "WebShop",
    ])

    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            # Check it has the expected module structure
            if (candidate / "web_agent_site").exists():
                if str(candidate) not in sys.path:
                    sys.path.insert(0, str(candidate))
                return


def _normalize_valid_actions(available: Any) -> list[str]:
    """Convert WebShop get_available_actions() output to List[str].

    WebShop returns:
      {"has_search_bar": bool, "clickables": ["foo", "bar", ...]}

    We convert to:
      ["search[<query>]", "click[foo]", "click[bar]", ...]
    """
    if available is None:
        return []
    if isinstance(available, list):
        return [str(a) for a in available]
    if isinstance(available, dict):
        actions: list[str] = []
        if available.get("has_search_bar", False):
            actions.append("search[<query>]")
        for c in available.get("clickables", []) or []:
            actions.append(f"click[{c}]")
        return actions
    return []


# Initialize path on module load
_maybe_add_webshop_to_syspath()


@dataclass
class WebShopConfig:
    """Configuration for WebShop environment."""
    
    env_name: str = "webshop"
    max_steps: int = 30
    reward_threshold: float = 0.8  # Consider success if reward >= threshold
    render: bool = False
    headless: bool = True
    observation_mode: str = "text"  # 'text', 'html', 'text_rich'
    
    @classmethod
    def from_yaml(cls, path: str) -> "WebShopConfig":
        import yaml
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**data.get("webshop", {}))


class WebShopEnvWrapper:
    """
    Wrapper for WebShop environment with state save/restore capabilities.
    
    Key features:
    - State serialization for snapshot creation
    - State restoration for evaluation from snapshots
    - Action space enumeration
    - Reward normalization
    """
    
    def __init__(self, config: Optional[WebShopConfig] = None):
        self.config = config or WebShopConfig()
        self._env = None
        self._current_task_id = None
        self._step_count = 0
        
    def _lazy_init(self):
        """Lazily initialize the environment."""
        if self._env is None:
            try:
                from web_agent_site.envs import WebAgentTextEnv
                self._env = WebAgentTextEnv(
                    observation_mode=self.config.observation_mode,
                    render=self.config.render,
                )
            except ImportError:
                raise ImportError(
                    "WebShop not found. Please install from: "
                    "https://github.com/princeton-nlp/WebShop"
                )
    
    def reset(self, task_id: Optional[Union[str, int]] = None) -> dict:
        """
        Reset environment to a new task.
        
        Args:
            task_id: Specific task ID, or None for random task
            
        Returns:
            Initial observation dict with keys:
            - observation: str
            - valid_actions: list[str]
            - task_id: str
            - instruction_text: str
        """
        self._lazy_init()
        
        if task_id is not None:
            observation, _ = self._env.reset(session=task_id)
        else:
            observation, _ = self._env.reset()
        
        self._current_task_id = self._env.session
        self._step_count = 0
        
        # Get instruction text for the task
        instruction_text = getattr(self._env, "instruction_text", "")
        
        # Get and normalize valid actions
        available = self._env.get_available_actions()
        valid_actions = _normalize_valid_actions(available)
        
        return {
            "observation": observation,
            "valid_actions": valid_actions,
            "task_id": self._current_task_id,
            "instruction_text": instruction_text,
        }
    
    def step(self, action: str) -> tuple[dict, float, bool, dict]:
        """
        Take action in environment.
        
        Args:
            action: Action string (e.g., "click[Buy Now]", "search[shoes]")
            
        Returns:
            observation: dict with observation and valid_actions
            reward: float reward value
            done: bool whether episode is complete
            info: dict with additional information
        """
        self._lazy_init()
        
        observation, reward, done, info = self._env.step(action)
        self._step_count += 1
        info = info or {}
        
        # Check max steps
        if self._step_count >= self.config.max_steps:
            done = True
            info["truncated"] = True
        
        # Get and normalize valid actions
        if not done:
            available = self._env.get_available_actions()
            valid_actions = _normalize_valid_actions(available)
        else:
            valid_actions = []
        
        return (
            {
                "observation": observation,
                "valid_actions": valid_actions,
            },
            reward,
            done,
            info,
        )
    
    def get_valid_actions(self) -> list[str]:
        """Get list of valid actions in current state as normalized strings."""
        self._lazy_init()
        
        try:
            available = self._env.get_available_actions()
            return _normalize_valid_actions(available)
        except AttributeError:
            # Fallback: parse from observation
            return self._parse_actions_from_observation()
    
    def _parse_actions_from_observation(self) -> list[str]:
        """Parse valid actions from observation text."""
        # This is a fallback; WebShop should provide get_available_actions
        actions = []
        # Add basic navigation
        actions.extend(["back", "search[<query>]"])
        return actions
    
    def get_state(self) -> bytes:
        """
        Serialize current environment state for later restoration.
        
        Returns:
            Serialized state as bytes
            
        Raises:
            RuntimeError: If WebShop env doesn't implement get_state()
        """
        self._lazy_init()
        
        if not hasattr(self._env, "get_state"):
            raise RuntimeError(
                "WebShop env does not implement get_state(). "
                "Patch WebShop-master/web_agent_site/envs/web_agent_text_env.py to add it "
                "(see WebShop state save/restore patch)."
            )
        
        env_state = self._env.get_state()
        
        state = {
            "task_id": self._current_task_id,
            "step_count": self._step_count,
            "env_state": env_state,
            "observation": self._env.observation if hasattr(self._env, "observation") else "",
            "instruction_text": getattr(self._env, "instruction_text", ""),
        }
        return pickle.dumps(state)
    
    def set_state(self, state_bytes: bytes) -> dict:
        """
        Restore environment to a previously saved state.
        
        Args:
            state_bytes: Serialized state from get_state()
            
        Returns:
            Observation dict after restoration
            
        Raises:
            RuntimeError: If WebShop env doesn't implement set_state()
        """
        self._lazy_init()
        
        if not hasattr(self._env, "set_state"):
            raise RuntimeError(
                "WebShop env does not implement set_state(). "
                "Patch WebShop-master/web_agent_site/envs/web_agent_text_env.py to add it "
                "(see WebShop state save/restore patch)."
            )
        
        state = pickle.loads(state_bytes)
        
        # Restore environment state directly (no reset needed)
        if state.get("env_state"):
            observation = self._env.set_state(state["env_state"])
        else:
            # Fallback: reset and try to restore
            self.reset(state["task_id"])
            observation = state.get("observation", "")
        
        self._current_task_id = state["task_id"]
        self._step_count = state.get("step_count", 0)
        
        # Get normalized valid actions
        available = self._env.get_available_actions()
        valid_actions = _normalize_valid_actions(available)
        
        return {
            "observation": observation if isinstance(observation, str) else state.get("observation", ""),
            "valid_actions": valid_actions,
            "instruction_text": state.get("instruction_text", ""),
        }
    
    def is_success(self, reward: float) -> bool:
        """Check if reward indicates task success."""
        return reward >= self.config.reward_threshold
    
    def close(self):
        """Close the environment."""
        if self._env is not None:
            self._env.close()
            self._env = None
    
    @property
    def task_id(self) -> Optional[str]:
        """Get current task ID."""
        return self._current_task_id
    
    @property
    def step_count(self) -> int:
        """Get current step count."""
        return self._step_count


class MockWebShopEnv(WebShopEnvWrapper):
    """
    Mock WebShop environment for testing and development.
    Simulates basic WebShop behavior without the actual environment.
    """
    
    def __init__(self, config: Optional[WebShopConfig] = None):
        super().__init__(config)
        self._mock_observation = ""
        self._mock_actions = []
        self._mock_done = False
    
    def _lazy_init(self):
        pass  # No real initialization needed
    
    def reset(self, task_id: Optional[str] = None) -> dict:
        self._current_task_id = task_id or f"mock_task_{id(self)}"
        self._step_count = 0
        self._mock_observation = f"[WebShop] Task: {self._current_task_id}\nFind and purchase the requested item."
        self._mock_actions = ["search[query]", "click[item]", "back"]
        self._mock_done = False
        
        return {
            "observation": self._mock_observation,
            "valid_actions": self._mock_actions,
            "task_id": self._current_task_id,
        }
    
    def step(self, action: str) -> tuple[dict, float, bool, dict]:
        self._step_count += 1
        
        # Simulate progression
        if "buy" in action.lower():
            self._mock_done = True
            reward = 0.9 if self._step_count < 10 else 0.5
        else:
            reward = 0.0
        
        if self._step_count >= self.config.max_steps:
            self._mock_done = True
        
        self._mock_observation = f"Step {self._step_count}: After action '{action}'"
        
        return (
            {
                "observation": self._mock_observation,
                "valid_actions": self._mock_actions if not self._mock_done else [],
            },
            reward,
            self._mock_done,
            {"step": self._step_count},
        )
    
    def get_valid_actions(self) -> list[str]:
        return self._mock_actions if not self._mock_done else []
    
    def get_state(self) -> bytes:
        return pickle.dumps({
            "task_id": self._current_task_id,
            "step_count": self._step_count,
            "observation": self._mock_observation,
            "actions": self._mock_actions,
            "done": self._mock_done,
        })
    
    def set_state(self, state_bytes: bytes) -> dict:
        state = pickle.loads(state_bytes)
        self._current_task_id = state["task_id"]
        self._step_count = state["step_count"]
        self._mock_observation = state["observation"]
        self._mock_actions = state["actions"]
        self._mock_done = state["done"]
        
        return {
            "observation": self._mock_observation,
            "valid_actions": self._mock_actions,
        }


def create_env(config: Optional[WebShopConfig] = None, mock: bool = False) -> WebShopEnvWrapper:
    """
    Factory function to create appropriate environment.
    
    Args:
        config: Environment configuration
        mock: If True, use mock environment for testing
        
    Returns:
        WebShopEnvWrapper instance
    """
    if mock:
        return MockWebShopEnv(config)
    return WebShopEnvWrapper(config)
